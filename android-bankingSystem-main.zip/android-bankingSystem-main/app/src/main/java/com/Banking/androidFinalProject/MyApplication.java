package com.Banking.androidFinalProject;

import android.app.Application;

import com.Banking.androidFinalProject.details.Account;
import com.Banking.androidFinalProject.details.Customer;

import java.util.ArrayList;

public class MyApplication extends Application {

    public static ArrayList<Customer> customers = new ArrayList<Customer>();
    public static ArrayList<Account> accounts = new ArrayList<Account>();

    @Override
    public void onCreate() {
        super.onCreate();
        customers.add(new Customer(001, "Rakesh", "09876", "1234"));
        customers.add(new Customer(002, "Chaitanya", "08765", "1345"));
        customers.add(new Customer(003, "Shiva", "07654", "1456"));
        customers.add(new Customer(004, "Srija", "06543", "1567"));
        customers.add(new Customer(005, "Navaneeth", "05432", "1678"));

        accounts.add(new Account(9876, 001, "rakesh@gmail.com",15000, "Salary"));
        accounts.add(new Account(8765, 001, "rakesh@gmail.com",10000, "Saving"));
        accounts.add(new Account(7654, 002, "chaitanya@gmail.com",11000, "Saving"));
        accounts.add(new Account(6543, 002, "chaitanya@gmail.com",20000, "Salary"));
        accounts.add(new Account(5432, 003, "shiva@gmail.com",13000, "Saving"));
        accounts.add(new Account(4321, 004, "srija@gmail.com",16000, "Salary"));
        accounts.add(new Account(1234, 005, "navaneeth@gmail.com",22000, "Saving"));
    }
}
